// declare variables here


function setup() {
  // put setup code here --> this runs once upon launch

  createCanvas(500, 500);
  background(0);
}


function draw() {
  // put drawing code here --> this loops every frame
}


// write custom functions here
